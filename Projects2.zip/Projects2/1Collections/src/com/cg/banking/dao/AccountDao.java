package com.cg.banking.dao;

import com.cg.banking.bean.AccountBean;

public interface AccountDao {

	public AccountBean checkAccount(long accNo);

	public void setData(long accNo, AccountBean bean);

}
