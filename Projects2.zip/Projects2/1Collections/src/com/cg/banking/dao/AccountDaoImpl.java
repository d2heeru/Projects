package com.cg.banking.dao;

import java.util.HashMap;

import com.cg.banking.bean.AccountBean;

public class AccountDaoImpl implements AccountDao {

	HashMap hashMap;
	AccountBean bean = new AccountBean();

	public AccountDaoImpl() {
		hashMap = new HashMap();
	}

	public AccountBean checkAccount(long accNo) {
		if (hashMap.containsKey(accNo)) {
			bean = (AccountBean) hashMap.get(accNo);
			return bean;
		} else
			return null;
	}

	public void setData(long accNo, AccountBean bean) {
		hashMap.put(accNo, bean);
	}
	
	public HashMap getData() {
		return hashMap;
	}
}