package com.cg.banking.bean;

public class AccountBean {

	/*
	 * Variables
	 */
	private String custName;
	private long accountNo;
	private int zipCode;
	private String address;
	private String phone;
	private int balance;

	String transactions = new String();

	/*
	 * Constructors
	 */
	public AccountBean() {
		super();
	}

	public AccountBean(String name, long accNo, int pin, String address, String phone, int balance) {
		super();
		this.custName = name;
		this.accountNo = accNo;
		this.zipCode = pin;
		this.address = address;
		this.phone = phone;
		this.balance = balance;
	}

	/*
	 * Getters & Setters
	 */
	public String getTrans() {
		return transactions;
	}

	public void setTrans(String string) {
		transactions = string;
	}

	public int getPin() {
		return zipCode;
	}

	public void setPin(int pin) {
		this.zipCode = pin;
	}

	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone2) {
		this.phone = phone2;
	}

	public String getName() {
		return custName;
	}

	public void setName(String name) {
		this.custName = name;
	}

	public long getAccNo() {
		return accountNo;
	}

	public long setAccNo(long accNo2) {
		return this.accountNo = accNo2;
	}

	public String getAddress() {
		return address;
	}

	public void setAdd(String address) {
		this.address = address;
	}

	/*
	 * To String Method
	 */
	@Override
	public String toString() {
		return "AccountDetails name =" + custName + "\n accNo =" + accountNo + "\n pin =" + zipCode + "\n address =" + address
				+ "\n phone =" + phone + "\nbalance =" + balance;
	}
}