package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BankDetails")
public class Bank {
	/*
	 * Variables
	 */
	@Column(name = "name")
	private String name;

	@Id
	@Column(name = "accountNo", length = 20)
	private long accountNo;

	@Column(name = "password", length = 20)
	private String password;

	@Column(name = "phoneNo", length = 20)
	private String phoneNo;

	@Column(name = "balance", length = 20)
	private int balance;

	/*
	 * Getters & Setters
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	/*
	 * To String
	 */
	@Override
	public String toString() {
		return "BankBean [name=" + name + ", accountNo=" + accountNo + ", password=" + password + ", phoneNo=" + phoneNo
				+ ", balance=" + balance + "]";
	}

}
