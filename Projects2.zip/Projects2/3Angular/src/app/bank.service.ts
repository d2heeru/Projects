import { Injectable } from '@angular/core';
import { Customer } from './customer';
import { Transaction } from './transaction';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  customer: Customer[] = [];
  transaction: Transaction[] = [];
  ShowCustomer: Customer;

  constructor() { }

  /*
  *  Create Account
  */
  add(customer: Customer, transaction: Transaction) {
    this.customer.push(customer);
    this.transaction.push(transaction);
    alert("Your Account Number : "+customer.accountNo);
  }

  /*
  *  Show Balance
  */
  showBalance(data: any): Customer {
    for (let i = 0; i < this.customer.length; i++) {
      let Cust = this.customer[i];
      if (Cust.accountNo == data.accountno) {
        if (Cust.pin == data.pin) {
          this.ShowCustomer = Cust;
          return this.ShowCustomer;
        }
      }
    }
  }

  /*
  *  Deposit
  */
  depositeBalance(data: any, transaction: Transaction) {
    for (let i = 0; i < this.customer.length; i++) {
      let Cust = this.customer[i];
      if (Cust.accountNo == data.depaccountno) {
        if (Cust.pin == data.deppin) {
          Cust.balance = Cust.balance + data.depbalance;
          alert("Successfully Deposited : " + data.depbalance);
          this.transaction.push(transaction);
          break;
        }
      }
    }
  }

  /*
  *  Withdraw
  */
  withdrawBalance(data: any, transaction: Transaction) {
    for (let i = 0; i < this.customer.length; i++) {
      let Cust = this.customer[i];
      if (Cust.accountNo == data.withdrawaccountno) {
        if (Cust.pin == data.withdrawpin) {
          if (Cust.balance > data.withdrawbalance) {
            Cust.balance = Cust.balance - data.withdrawbalance;
            this.transaction.push(transaction);
            alert("Successfully Withdraw : " + data.withdrawbalance);
            break;
          }
        }
      }
    }
  }

  /*
  *  Transfer Funds
  */
  transferBalance(data: any, transaction: Transaction, transaction1: Transaction) {
    for (let i = 0; i < this.customer.length; i++) {
      let Cust = this.customer[i];
      if (Cust.accountNo == data.fromaccountno) {
        if (Cust.pin == data.frompin) {
          if (Cust.balance > data.transferbalance) {
            for (let i = 0; i < this.customer.length; i++) {
              let Customr = this.customer[i];
              if (Customr.accountNo == data.toaccountno) {
                Cust.balance = Cust.balance - data.transferbalance;
                Customr.balance = Customr.balance + data.transferbalance;
                this.transaction.push(transaction);
                console.log(transaction);
                console.log(transaction1);
                this.transaction.push(transaction1);
                alert("Successfully Transferred : " + data.transferbalance);
                break;
              }
            }
          }
        }
      }
    }
  }

  /*
  *  Print Transaction
  */
  printTransaction(data: any): Transaction[] {
    let printTransactions: Transaction[] = [];
    for (let i = 0; i < this.customer.length; i++) {
      let customer = this.customer[i];
      if (customer.accountNo == data.transaccountno) {
        if (customer.pin == data.transpin) {
          for (let i = 0; i < this.transaction.length; i++) {
            let trans = this.transaction[i];
            if (trans.accountNum == data.transaccountno) {
              printTransactions.push(trans);
            }
          }
          return printTransactions;
        }
      }
    }
  }
}
