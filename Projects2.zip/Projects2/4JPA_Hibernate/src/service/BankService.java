package service;

import dao.BankDAO;
import entity.BankDetails;
import entity.TransactionDetails;

public class BankService implements BankServiceI {
	
	BankDAO dao = new BankDAO();

	/*
	 * Method to fetch Account based on ID
	 */
	@Override
	public BankDetails getAccountById(int id) {
		BankDetails bank = dao.getAccountById(id);
		return bank;
	}

	/*
	 * Method to Create Account
	 */
	@Override
	public void CreateAccount(BankDetails bank) {
		dao.beginTransaction();
		dao.CreateAccount(bank);
		dao.commitTransaction();
	}

	/*
	 * Method to Show Balance
	 */
	@Override
	public void ShowBalance(BankDetails bank) {
		// TODO Auto-generated method stub
	}

	/*
	 * Method to Deposit
	 */
	@Override
	public void Deposit(BankDetails bank) {
		dao.beginTransaction();
		dao.Deposit(bank);
		dao.commitTransaction();
	}

	/*
	 * Withdraw
	 */
	@Override
	public void Withdraw(BankDetails bank) {
		dao.beginTransaction();
		dao.Withdraw(bank);
		dao.commitTransaction();
	}

	/*
	 * Print the Transactions
	 */
	@Override
	public void PrintTransactions(int id) {
		dao.PrintTransactions(id);
	}

	/*
	 * Method to Commit Transactions
	 */
	@Override
	public void commitTransaction() {
		dao.commitTransaction();
	}

	/*
	 * Method to Begin Transaction
	 */
	@Override
	public void beginTransaction() {
		dao.beginTransaction();
	}

	/*
	 * Method to Add a Transaction
	 */
	public void addTransaction(TransactionDetails trans) {
		dao.beginTransaction();
		dao.addTransaction(trans);
		dao.commitTransaction();
	}

}
