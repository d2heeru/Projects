package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import entity.BankDetails;
import entity.TransactionDetails;

public class BankDAO implements BankDAOI {

	EntityManager entity = UtilJava.getEntityManager();

	/*
	 * Get Account based on ID
	 */
	@Override
	public BankDetails getAccountById(int id) {
		BankDetails bank = entity.find(BankDetails.class, id);
		return bank;
	}

	/*
	 * Create Account
	 */
	@Override
	public void CreateAccount(BankDetails bank) {
		entity.persist(bank);
	}

	/*
	 * Show Balance
	 */
	@Override
	public void ShowBalance(BankDetails bank) {
		// TODO Auto-generated method stub
	}

	/*
	 * Deposit
	 */
	@Override
	public void Deposit(BankDetails bank) {
		entity.merge(bank);
	}

	/*
	 * Withdraw
	 */
	@Override
	public void Withdraw(BankDetails bank) {
		entity.merge(bank);
	}

	/*
	 * Print Transactions
	 */
	public void PrintTransactions(int id) {
		Query q = entity.createQuery("select t from TransactionDetails t where accId=:tid");
		q.setParameter("tid", id);
		List<TransactionDetails> l = q.getResultList();
		System.out.println("TransactionId		Account Id		TrasactionType		Amount");
		System.out.println("------------------------------------------------------------------");
		for (TransactionDetails tdetails : l) {
			System.out.println(tdetails.getTransactionId() + "			" + tdetails.getAccId() + "			"
					+ tdetails.getTransactionType() + "		" + tdetails.getAmount());
		}
	}

	/*
	 * Method to commit Transaction
	 */
	@Override
	public void commitTransaction() {
		entity.getTransaction().commit();
	}

	/*
	 * Method to begin Transaction
	 */
	@Override
	public void beginTransaction() {
		entity.getTransaction().begin();
	}

	/*
	 * Method to Add Transaction
	 */
	public void addTransaction(TransactionDetails trans) {
		entity.persist(trans);
	}

}
