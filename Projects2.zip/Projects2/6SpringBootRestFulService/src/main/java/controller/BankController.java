package controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import entities.BankEntity;
import entities.TransactionEntity;
import exception.BankException;
import service.BankService;

@RestController
@RequestMapping("/Bank")
public class BankController {

	/*
	 * Autowiring with Service Class
	 */
	@Autowired
	BankService bankService;

	/*
	 * Mapping for Options Menu
	 */
	@GetMapping("/ShowOptions")
	public ResponseEntity<String> ShowOptions() {
		return new ResponseEntity<String>("Welcome to XYZ Wallet\n\n" 
				+ "1. Create Account 		: 	/CreateAccount\n"
				+ "2. Show Details 			: 	/ShowDetails/{accNo}\n" 
				+ "3. Show Balance			: 	/ShowBalance/{accNo}\n"
				+ "4. Deposite Amount 		: 	/DepositAmount/{accNo}/{amt}\n"
				+ "5. Withdraw Amount 		: 	/WithdrawAmount/{accNo}/{amt}\n"
				+ "6. Fund Transafer 		: 	/FundTransfer/{accNo1}/{amt}/{accNo2}\n"
				+ "7. Print Transactions 	: 	/MiniStatement/{accNo}", HttpStatus.OK);
	}

	/*
	 * Create Account
	 */
	@PostMapping("/CreateAccount")
	public BankEntity createAccount(@RequestBody BankEntity bank) throws BankException {
		return bankService.createAccount(bank);
	}

	/*
	 * Show Details
	 */
	@GetMapping("/ShowDetails/{accNo}")
	public BankEntity accountsDetails(@PathVariable Long accNo) throws BankException {
		return bankService.accountsDetails(accNo);
	}

	/*
	 * Show Balance
	 */
	@GetMapping("/ShowBalance/{accNo}")
	public ResponseEntity<String> showBalance(@PathVariable Long accNo) throws BankException {
		Double bal = bankService.showBalance(accNo);
		return new ResponseEntity<String>("Available Balance: " + bal, HttpStatus.OK);
	}

	/*
	 * Deposit
	 */
	@PutMapping("/DepositAmount/{accNo}/{amount}")
	public ResponseEntity<String> deposit(@PathVariable Long accNo, @PathVariable Double amount) throws BankException {
		Double bal = bankService.deposit(accNo, amount);
		return new ResponseEntity<String>("Amount Deposite Successfully \n" + "\n\nTransaction Amount : " + amount
				+ "\n\n__________________________________________\n" + "Your Updated Balance : " + bal
				+ "\n__________________________________________", HttpStatus.OK);
	}

	/*
	 * Withdraw
	 */
	@PutMapping("/WithdrawAmount/{accNo}/{amount}")
	public ResponseEntity<String> withdraw(@PathVariable Long accNo, @PathVariable Double amount) throws BankException {
		Double bal = bankService.withdraw(accNo, amount);
		return new ResponseEntity<String>("Amount Withdrawn Successfully :-)\n" + "\n\nTransaction Amount : " + amount
				+ "\n\n_________________________________________\n" + "Your Updated Balance : " + bal
				+ "\n__________________________________________", HttpStatus.OK);
	}

	/*
	 * Funds Transfer
	 */
	@PutMapping("/FundTransfer/{sender}/{amount}/{reciver}")
	public ResponseEntity<String> fundTransfer(@PathVariable Long sender, @PathVariable Double amount,
			@PathVariable Long reciver) throws BankException {
		Double bal = bankService.fundTransfer(sender, amount, reciver);
		return new ResponseEntity<String>(
				"Amount Transferred Successfully :-)\n__________________________________________"
						+ "\n\nTransaction Amount : " + amount + "\nTransferred to : " + reciver
						+ "\n\n__________________________________________\n" + "Your Updated Balance : " + bal
						+ "\n__________________________________________",
				HttpStatus.OK);
	}

	/*
	 * Print Tranaction
	 */
	@GetMapping("/Transactions/{accNo}")
	public List<TransactionEntity> printTransaction(@PathVariable Long accNo) throws BankException {
		return bankService.printTransaction(accNo);
	}

}
