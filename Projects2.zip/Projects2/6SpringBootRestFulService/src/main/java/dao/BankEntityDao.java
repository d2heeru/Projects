package dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import entities.BankEntity;

@Repository
public interface BankEntityDao extends JpaRepository<BankEntity, Long> {

	/*
	 * Query for Account Details
	 */
	@Query("select accNo,password,name,address from BankEntity where accNo =?1")
	Optional<BankEntity> accountsDetails(@Param("c") Long accNo);

	/*
	 * Query to show Balance
	 */
	@Query("select be.balance from BankEntity be where be.accNo =?1")
	Optional<Double> showBalance(@Param("c") Long accNo);
}