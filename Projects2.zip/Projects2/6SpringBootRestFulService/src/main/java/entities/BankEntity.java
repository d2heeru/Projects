package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class BankEntity {

	/*
	 * Variables
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 15)
	private Long accNo;

	@Min(4)
	@Max(20)
	@Column(length = 15)
	private String password;

	@Min(4)
	@Max(20)
	@Column(length = 15)
	private String name;

	@Min(4)
	@Max(20)
	@Column(length = 15)
	private String address;

	@Column(length = 20)
	private Double balance;

	@Min(10)
	@Max(11)
	@Column(length = 10)
	private String mobNo;

	/*
	 * Constructor
	 */
	public BankEntity(Long accNo, String password, String name, String address, Double balance, String mobNo) {
		super();
		this.accNo = accNo;
		this.password = password;
		this.name = name;
		this.address = address;
		this.balance = balance;
		this.mobNo = mobNo;
	}

	/*
	 * Getters & Setters
	 */
	public Long getAccNo() {
		return accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}

	public BankEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	/*
	 * To String Method
	 */
	@Override
	public String toString() {
		return "BankEntity [accNo=" + accNo + ", pwd=" + password + ", name=" + name + ", address=" + address + ", bal="
				+ balance + ", mobNo=" + mobNo + "]";
	}

}
