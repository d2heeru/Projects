package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.BankEntityDao;
import dao.TransactionEntityDao;
import entities.BankEntity;
import entities.TransactionEntity;
import exception.BankException;

@Service
public class BankServiceImpl implements BankService {

	/*
	 * AutoWiring with Bank DAO
	 */
	@Autowired
	BankEntityDao bankDao;

	/*
	 * Autowiring with Transaction DAO
	 */
	@Autowired
	TransactionEntityDao transDao;

	/*
	 * Create Account
	 */
	public BankEntity createAccount(BankEntity bank) throws BankException {
		if (bank.getBalance() == null || bank.getBalance() <= 0) {
			throw new BankException("Balance can not be 0");
		} else {
			bankDao.save(bank);
			return bankDao.findById(bank.getAccNo()).get();
		}
	}

	/*
	 * Account Details
	 */
	public BankEntity accountsDetails(Long accNo) throws BankException {
		if (!bankDao.findById(accNo).isPresent()) {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		} else {
			return bankDao.findById(accNo).get();
		}
	}

	/*
	 * Show Balance
	 */
	public Double showBalance(Long accNo) throws BankException {
		if (!bankDao.findById(accNo).isPresent()) {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		} else {
			return bankDao.findById(accNo).get().getBalance();
		}
	}

	/*
	 * Deposit
	 */
	public Double deposit(Long accNo, Double amt) throws BankException {

		Optional<BankEntity> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			BankEntity tempEntity = bank.get();
			tempEntity.setBalance(bank.get().getBalance() + amt);
			bankDao.save(tempEntity);
			TransactionEntity trans = new TransactionEntity(accNo, "Deposite", bank.get().getBalance(),
					bank.get().getBalance() + amt);
			transDao.save(trans);
			return showBalance(accNo);
		} else {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	/*
	 * Withdraw
	 */
	public Double withdraw(Long accNo, Double amt) throws BankException {
		Optional<BankEntity> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			if (amt > showBalance(accNo)) {
				throw new BankException("Insufficient Balance :-(");
			} else {
				BankEntity tempEntity = bank.get();
				tempEntity.setBalance(bank.get().getBalance() - amt);
				bankDao.save(tempEntity);
				TransactionEntity trans = new TransactionEntity(accNo, "Withdraw", bank.get().getBalance(),
						bank.get().getBalance() - amt);
				transDao.save(trans);
				return showBalance(accNo);
			}
		} else {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	/*
	 * Funds Transfer
	 */
	public Double fundTransfer(Long senderAcc, Double amt, Long reciverAcc) throws BankException {
		Optional<BankEntity> senderAccount = bankDao.findById(senderAcc);
		Optional<BankEntity> reciverAccount = bankDao.findById(reciverAcc);
		if (senderAccount.isPresent() && reciverAccount.isPresent()) {
			BankEntity sender = senderAccount.get();
			sender.setBalance(senderAccount.get().getBalance() - amt);
			bankDao.save(sender);
			BankEntity reciver = reciverAccount.get();
			reciver.setBalance(reciverAccount.get().getBalance() + amt);
			bankDao.save(reciver);
			TransactionEntity senderTrans = new TransactionEntity(senderAcc, "Fund Transfer",
					senderAccount.get().getBalance(), senderAccount.get().getBalance() - amt);
			transDao.save(senderTrans);
			TransactionEntity reciverTrans = new TransactionEntity(reciverAcc, "Fund Recieved",
					reciverAccount.get().getBalance(), amt + reciverAccount.get().getBalance());
			transDao.save(reciverTrans);
			return showBalance(senderAcc);
		} else {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	/*
	 * Print Transactions
	 */
	public List<TransactionEntity> printTransaction(Long accNo) throws BankException {
		if (!bankDao.findById(accNo).isPresent()) {
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		} else {
			return transDao.printTransaction(accNo);
		}
	}
}
