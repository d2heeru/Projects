package bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankMain {

	public static void main(String[] args) {
		SpringApplication.run(BankMain.class, args);
	}

}