package com.capgemini.banking.bean;

public class Transaction {
	private String transId;
	private float transAmount;
	private String transDate;
	public Transaction(String transId, float transAmount, String transDate) {
		super();
		this.transId = transId;
		this.transAmount = transAmount;
		this.transDate = transDate;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public float getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(float transAmount) {
		this.transAmount = transAmount;
	}
	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", transAmount=" + transAmount + ", transDate=" + transDate + "]";
	}
	
	
}
