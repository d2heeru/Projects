package com.capgemini.banking.bean;

public class Account {
	private static int accountNo = 1514113355;
	private final String accountType  = "Saving";
	private double openingBalance;
    private double currentBalance;
	private final String accountStatus = "Active";
    private Customer customer;
	
    
    public Account(Customer customer,  double openingBalance) {
		super();
		this.accountNo = getAccountNo();
		this.currentBalance = openingBalance;
		this.customer = customer;
		setOpeningBalance(openingBalance);
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}



	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getAccountStatus() {
		return accountStatus;
	}


	@Override
	public String toString() {
		return "Account [account number=" + accountNo++ +", accountType=" + accountType + ", openingBalance=" + openingBalance + ", currentBalance="
				+ currentBalance + ", accountStatus=" + accountStatus +"]" + "\n" + "customer=" + customer + "]";
	}
	

}
