package com.capgemini.banking.operations;

import java.util.List;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.bean.Customer;

public interface Operations {
	public Account createAccount(Account account);
	public Account showBalance(int accountNo);
	public void deposite(int accountNo, double amount);
	public void withdraw(int accountNo, double amount);
	public void fundTransfer();
	public void printTransactions();
	
}
