package com.capgemini.banking.operations;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.banking.bean.Account;

public class OperationsImpl implements Operations{

	Map<Integer, Account> map_Account;
	
	
	public OperationsImpl(int size) {
		map_Account = new HashMap<Integer, Account>(size);
	}

	@Override
	public Account createAccount(Account account) {
		return map_Account.put(account.getAccountNo(), account);
		
	}

	@Override
	public Account showBalance(int accountNo) {
		Account account = map_Account.get(accountNo);
		
		return map_Account.get(accountNo);
		
	}

	@Override
	public void deposite(int accountNo, double amount) {
		Account account = map_Account.get(accountNo);
		double currentBalance = account.getCurrentBalance();
		currentBalance += amount;
		account.setCurrentBalance(currentBalance);
		
	}

	@Override
	public void withdraw(int accountNo, double amount) {
		Account account = map_Account.get(accountNo);
		double currentBalance = account.getCurrentBalance();
		currentBalance -= amount;
		account.setCurrentBalance(currentBalance);
		
	}

	@Override
	public void fundTransfer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTransactions() {
		// TODO Auto-generated method stub
		
	}

	

}
