package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.bean.Address;
import com.capgemini.banking.bean.Customer;
import com.capgemini.banking.operations.Operations;
import com.capgemini.banking.operations.OperationsImpl;

public class Main_acc {
	static Scanner scan = new Scanner(System.in);
	public static Account getInputAccount(){
		String firstName = getInput("Enter first name : ");
		String lastName = getInput("Enter last name : ");
		String phone = getInput("Enter User Phone Number : ");
		String email = getInput("Enter Email Id : ");
		String sex = getInput("Enter sex of the User : ");
		String dob = getInput("Enter Date of Birth : ");
		String addType = getInput("Enter Address Type : ");
		String  add  = getInput("Enter Adress : ");
		String  city = getInput("Enter city : ");
		String state = getInput("Enter state : ");
		String zip = getInput("Enter Zip Code : ");
		String country = getInput("Enter Country : ");
	    Address address = new Address(addType, add, city, state, zip, country);
		Customer customer = new Customer(firstName, lastName, phone, email, sex, dob, address);
	    Account account = new Account(customer,500);
		return account;
	}
	private static String getInput(String message) {
		System.out.println(message);
		return scan.next();
	}
	public static void main(String[] args) {
		Operations operation = new OperationsImpl(5);
		int choice = 0;
		int accountNo;
		double amount;
		Account account;
		System.out.println("*******Welcome To Lena Bank*******");
		do{
			System.out.println("\n1. Create Account \n2. Show Balance \n"
					+ "3. Deposite \n4. Withdraw \n5. Fund Transfer\n6. Print Transactions\n7. Exit");
			choice = scan.nextInt();
			if(choice==1){
				account = getInputAccount();
			    operation.createAccount(account);
				System.out.println("Account Created -------------------------->");
				System.out.println(account);
				}
			if(choice==2){
				accountNo = Integer.parseInt(getInput("\nEnter Account No :"));
				account = operation.showBalance(accountNo);
				System.out.println("Current Balance : " + account.getCurrentBalance());
			}
			if(choice == 3){
				accountNo = Integer.parseInt(getInput("\nEnter Account No :"));
				amount = Double.parseDouble(getInput("\nEnter Amount"));
				operation.deposite(accountNo, amount);
			}
			if(choice == 4){
				accountNo = Integer.parseInt(getInput("\nEnter Account No :"));
				amount = Double.parseDouble(getInput("\nEnter Amount"));
				operation.withdraw(accountNo, amount);
			}
		}while(choice!=7);
		
	}
}
