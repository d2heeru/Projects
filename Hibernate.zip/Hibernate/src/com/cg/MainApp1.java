package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import java.util.*;


public class MainApp1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		// Display database Table
		
		/*System.out.println("Enter Gender");
		String gender = scan.nextLine();
		
		TypedQuery<Employee> query = em.createQuery("from Employee where gender=:gen", Employee.class);
		
		query.setParameter("gen",gender);
	
		 List<Employee> employee = query.getResultList();
		 
		 for(Employee employee1 : employee){
			 System.out.println(employee1);
		 }*/
		
		
		//Deleting Rows
		
		
		/*System.out.println("Enter Employee Id");
		int empId = scan.nextInt();
		
		Query query = em.createQuery("delete from Employee where id=:eno");
		query.setParameter("eno", empId);
		em.getTransaction().begin();
		int result = query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result+"rows deleted");
		*/
		
		//select specific id using query
		
		/*System.out.println("Enter Employee Id to select");
		int empId = scan.nextInt();
		TypedQuery<Employee> query = em.createQuery("from Employee where id=:eno",Employee.class);
		query.setParameter("eno", empId);
		Employee emp = query.getSingleResult();
		System.out.println(emp);*/
		
		//Update Operation
		
		/*System.out.println("Enter Employee Gender");
		String gender = scan.nextLine();
		System.out.println("Enter Salary");
		double sal = scan.nextDouble();
		System.out.println("Enter Age number");
		int ageNum = scan.nextInt();
		
		Query query = em.createQuery("update Employee set salary=salary+:s,age=age+:a where gender=:g");
		query.setParameter("s", sal);
		query.setParameter("a", ageNum);
		query.setParameter("g", gender);
		
		em.getTransaction().begin();
		int result = query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result+"row(s) updated");
		*/
		
		TypedQuery<Employee> query = em.createNamedQuery("getAllEmployees",Employee.class);
		
		List<Employee> employees =query.getResultList();
		
		for(Employee employee : employees){
			 System.out.println(employee);
		 }
		
		System.out.println("_______________________________________________________");
		query = em.createNamedQuery("getEmployeeByGender",Employee.class);
		query.setParameter("gen", "Male");
		List<Employee> employeeGen = query.getResultList();
		for(Employee employee : employeeGen){
			 System.out.println(employee);
		 }
	}

}
