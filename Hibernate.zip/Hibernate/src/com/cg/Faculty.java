package com.cg;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class Faculty {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	
	/*@OneToOne(cascade = CascadeType.ALL,mappedBy="faculty")
	@JoinColumn(name="techId")
	private Technology technology;
	
	public Technology getTechnology() {
		return technology;
	}
	public void setTechnology(Technology technology) {
		this.technology = technology;
	}*/
	
	@OneToMany(cascade = CascadeType.PERSIST, mappedBy = "faculties")
	//@JoinTable(name="factech",joinColumns=@JoinColumn(name="factid"),inverseJoinColumns = @JoinColumn(name="techId"))
	private List<Technology> technology = new ArrayList<>();
	
	
	
	public List<Technology> getTechnology() {
		return technology;
	}
	public void setTechnology(List<Technology> technology) {
		this.technology = technology;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Faculty [id=" + id + ", name=" + name + "]";
	}
	

}
