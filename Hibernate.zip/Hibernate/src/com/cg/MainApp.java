package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

 

public class MainApp {
    public static void main(String[] args){
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em = factory.createEntityManager();
     /*   Employee emp = new Employee(200, 11, "Dheeraj", "male", 100000);
        em.getTransaction().begin();
        em.persist(emp);
        em.getTransaction().commit();
        System.out.println("Data Saved");*/
        em.getTransaction().begin();
        Employee emp = em.find(Employee.class, 102);
        System.out.println(emp);
        emp.setSalary(77000);
        em.getTransaction().commit();
        System.out.println("After commit");
        System.out.println(emp);
    }
}