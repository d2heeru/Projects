package com.cg;

 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

 

@Entity
@Table(name="employee_details")

@NamedQueries({
@NamedQuery(name="getAllEmployees",query="from Employee"),
@NamedQuery(name="getEmployeeByGender",query="from Employee where gender=:gen")
})

public class Employee {
    @Id
    @Column(name="empId")
    private int id;
    @Column(name="empName")
    private String name;
    private String gender;
    private int age;
    @Column(name="annualSalary")
    private double salary;
   
    
    
    public Employee() {
		// TODO Auto-generated constructor stub
	}
    
    
    public Employee(int id, int age, String name, String gender, double salary) {
        super();
        this.id = id;
        this.age = age;
        this.name = name;
        this.gender = gender;
        this.salary = salary;
    }


    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    @Override
    public String toString() {
        return String.format("Employee [id=%s, age=%s, name=%s, gender=%s, salary=%s]", id, age, name, gender, salary);
    }
}