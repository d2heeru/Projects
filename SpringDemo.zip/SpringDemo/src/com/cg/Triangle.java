package com.cg;

import java.nio.channels.Pipe;
import java.util.List;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Triangle{
	/*
	private String type;
	private int height;
	
	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public Triangle() {
	}
	
	public Triangle(int height){
		this.height=height;
	}
	public Triangle(String type) {
		super();
		this.type = type;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public void draw(){
		System.out.println(type + " Triangle Drawn with height " + height);
	}

	public Triangle(String type, int height) {
		super();
		this.type = type;
		this.height = height;
	}
*/

	private Point pointA;
	private Point pointB;
	private Point pointC;
	public Point getPointA() {
		return pointA;
	}
	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}
	public Point getPointB() {
		return pointB;
	}
	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}
	public Point getPointC() {
		return pointC;
	}
	public void setPointC(Point pointC) {
		this.pointC = pointC;
	}
	
	public void draw(){
		System.out.println("Point A ("+pointA.getX()+","+pointA.getY()+")");
		System.out.println("Point B ("+pointB.getX()+","+pointB.getY()+")");
		System.out.println("Point C ("+pointC.getX()+","+pointC.getY()+")");
	}
/*	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("After PRopertities set of Initialing Bean");
		
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("Disposable bean destroy method ");
		
	}*/
	
/*	
	public void myInit(){
		System.out.println("My init Method executed");
	}
	
	public void tearDown(){
		System.out.println("My Destroy method executed");
	}*/
	//Collections
	
/*	private List<Point> points;

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}
	
	public void draw(){
		for(Point point : points){
			System.out.println("point (" + point.getX()+","+point.getY()+")");
		}
	}*/
	
}
