package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Circle  implements BeanNameAware,BeanFactoryAware,ApplicationContextAware,InitializingBean,DisposableBean{
	private Point center;

	public Point getCenter() {
		return center;
	}

	public void setCenter(Point center) {
		this.center = center;
	}
	
	public void draw(){
		System.out.println("Circle Point (" + center.getX()+","+center.getY()+")");
	}

	@Override
	public void setBeanName(String beanName) {
		System.out.println("Bean Name awer "+beanName);
		
	}

	@Override
	public void setBeanFactory(BeanFactory arg0) throws BeansException {
		System.out.println("BeanFactory awer method executed");
		
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		System.out.println("Application Context Awar Method executed");
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Intilizing bean after Properties set");
		
	}
	public void myInit(){
		System.out.println("My Init Method is executed");
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("Disposable Bean Destroy method executed");
		
	}
	
	public void tearDown(){
		System.out.println("My destroy method executed");
	}
}
